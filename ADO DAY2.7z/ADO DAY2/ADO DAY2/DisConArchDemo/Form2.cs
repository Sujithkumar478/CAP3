﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace DisConArchDemo
{
    public partial class Form2 : Form
    {
        SqlConnection con;
        SqlDataAdapter adap1;
        DataSet ds;
        SqlCommandBuilder bldr;
        public Form2()
        {
            InitializeComponent();
            con = new SqlConnection(@"server=.\sqlexpress;Integrated Security = TRUE;Database =EMPLOYEE ");
            //con.ConnectionString = @"server=.\sqlexpress;Integrated Security = TRUE;Database =EMPLOYEE ";
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            adap1 = new SqlDataAdapter("select * from CGEMPLOYEE", con);
            ds = new DataSet();
            adap1.Fill(ds, "CGEMP");
            //DATA BINDING
            textBox1.DataBindings.Add("text", ds.Tables["CGEMP"], "EMPID");
            textBox2.DataBindings.Add("text", ds.Tables["CGEMP"], "EMPNAME");
            textBox3.DataBindings.Add("text", ds.Tables["CGEMP"], "PHONE");
            textBox4.DataBindings.Add("text", ds.Tables["CGEMP"], "ADDR");
            dataGridView1.DataSource = ds.Tables["CGEMP"];
        }

        private void button4_Click(object sender, EventArgs e)
        {
            BindingContext[ds.Tables[0]].Position = 0;

        }

        private void button3_Click(object sender, EventArgs e)
        {
            //method 1
            //int rowCnt = BindingContext[ds.Tables[0]].Position;
            //BindingContext[ds.Tables[0]].Position = rowCnt-1;
            //method 2
            BindingContext[ds.Tables[0]].Position -= 1;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            BindingContext[ds.Tables[0]].Position += 1;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int totRowCount = ds.Tables[0].Rows.Count;
            BindingContext[ds.Tables[0]].Position = (totRowCount - 1);
        }
        
        private void btnAdd_Click(object sender, EventArgs e)
        {
            bldr = new SqlCommandBuilder(adap1);
            this.BindingContext[ds.Tables[0]].EndCurrentEdit();
            adap1.Update(ds, "CGEMP");//IT UPDATES THE CHANGES TO DB ALSO
            MessageBox.Show("record inserted successfully");
        }
        
        private void button5_Click(object sender, EventArgs e)
        {
            foreach (Control item in this.Controls)
            {
                TextBox tb;
                if (typeof(TextBox) == item.GetType())
                {
                    tb = (TextBox)item;
                    tb.Clear();
                }
            }
            //adding blank row
            this.BindingContext[ds.Tables[0]].AddNew();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            bldr = new SqlCommandBuilder(adap1);
            int row = this.BindingContext[ds.Tables[0]].Position;
            this.BindingContext[ds.Tables[0]].RemoveAt(row);
            adap1.Update(ds, "CGEMP");
            MessageBox.Show("record deleted successfully");

        }
    }
}
