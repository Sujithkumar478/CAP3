﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace DisConArchDemo
{
    public partial class Form1 : Form
    {
        SqlConnection con;
        SqlDataAdapter adap1,adap2;
        DataSet ds;
        public Form1()
        {
            InitializeComponent();
            con = new SqlConnection();
            con.ConnectionString = @"server=.\sqlexpress;Integrated Security = TRUE;Database =EMPLOYEE ";//TRUE REPRESENTS IT DEALS WITH MODERN VERSIONS ONLY
        }

       

        private void button1_Click(object sender, EventArgs e)
        {
            //Writing XML Schema
            ds.Tables[0].WriteXml("Mydata.xml");
        }
        

        private void button2_Click(object sender, EventArgs e)
        {
            ds.Tables[0].WriteXmlSchema("MydataSchema.xml");
        }
        private void button3_Click(object sender, EventArgs e)
        {
            //reading xml schema
            DataSet myds = new DataSet();
            myds.ReadXml("Mydata.xml");
            dataGridView1.DataSource = myds.Tables[0];
        }

        private void button4_Click(object sender, EventArgs e)
        {
            DataSet myds = new DataSet();
            myds.ReadXmlSchema("Mydataschema.xml");
            dataGridView1.DataSource = myds.Tables[0];
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            adap1 = new SqlDataAdapter("select * from CGEMPLOYEE",con);
            adap2 = new SqlDataAdapter("select*from PARENT_TBL", con);
            //loading data in dataset
            ds = new DataSet();
            //filling data in dataset
            adap1.Fill(ds, "CGEMP");//IT REMAINS CGEMPLOYEE IN SERVER BUT CGEMP REPRESENTS CGEMPLOYEE IN SERVER
            adap2.Fill(ds, "PTBL");//PTBL REPRESENTS PARENT TABLE
            //BINDING DATA TO UI CONTROLS ie DATAGRID AND DATAGRIDVIEW IN FORM1 DESIGN
            //dataGrid1.DataSource = ds;//comment it when ur using new dataset for grid in button 3 and button 4
            dataGridView1.DataSource = ds.Tables[0];//TO VIEW DATA IN DATAGRIDVIEW IT FILLS WITH 1ST TABLE AND REMAINING TABLE WILL BE ZERO
            textBox1.Text = ds.Tables[0].Rows[2][ 1].ToString();
            //------------------------------------------------------------------------------------------------------
            //method 2 to add code in buttons without button functions
            //ds.Tables[0].WriteXml("Mydata.xml");
            //ds.Tables[0].WriteXmlSchema("MydataSchema.xml");
            //reading schema
            //button 3
            //DataSet myds = new DataSet();
            //myds.ReadXml("Mydata.xml");
            //------------------------------------------------------------------------------------------------------------
        }
    }
}
