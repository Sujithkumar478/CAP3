﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data.SqlClient;
using System.Windows.Forms;
using EmployeeEntity;
using EmployeeBL;

namespace WPFEmployeeDemo
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Employee emp1;
        EmpBL empbl;
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            emp1 = new Employee();
            emp1.EmpId= Convert.ToInt32(textbox1.Text);
            emp1.EmpName = textbox2.Text;
            emp1.Phone = textbox3.Text;
            emp1.Addr = textbox4.Text;
            //calling bl
            empbl = new EmpBL();
            bool res = empbl.AddEmployee(emp1);
            if(res)
            {
                System.Windows.Forms.MessageBox.Show("record is added succesfully");
            }
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            //empbl = new EmpBL();
            //Employee myEmp = empbl.SearchEmployeeByID(Int32.Parse(textbox1.Text));
            //if(myEmp != null)
            //{
            //    textbox2.Text
            //}
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            

        }
    }
}
