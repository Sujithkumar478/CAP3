﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EmployeeEntity;
using EmployeeException;
//adding references
using System.Data;
using System.Data.SqlClient;

namespace EmployeeDAL
{
    public class EmployeeDAO
    {
        SqlConnection con;
        SqlCommand cmd;
        SqlDataReader sdr;
        DataTable dt;
        public EmployeeDAO()
        {
            con = new SqlConnection();
            con.ConnectionString = @"server=.\sqlexpress;Integrated Security = TRUE;Database =EMPLOYEE ";
        }
        #region Methods
        public bool AddEmployee(Employee emp)
        {
            bool flag = true;
            try
            {
                con.Open();
                SqlParameter p1, p2, p3, p4;
                p1 = new SqlParameter("@eid", emp.EmpId);
                p2 = new SqlParameter("@ename", emp.EmpName);
                p3 = new SqlParameter("@ephone", emp.Phone);
                p4 = new SqlParameter("@eaddr", emp.Addr);
                cmd = new SqlCommand();
                cmd.CommandText = "Insert into CGEMPLOYEE Values(@eid,@ename,@ephone,@eaddr)";
                cmd.CommandType = CommandType.Text;
                cmd.Connection = con;
                //adding params to command
                cmd.Parameters.Add(p1);
                cmd.Parameters.Add(p2);
                cmd.Parameters.Add(p3);
                cmd.Parameters.Add(p4);
                //executing command
                int resCnt = cmd.ExecuteNonQuery();

                if(resCnt>0)
                {
                    flag = true;
                }
                else
                {
                    flag = false;
                }
            }
            catch(SqlException e)
            {
                throw e;
            }
            catch(Exception e)
            {
                throw e;
            }
            finally
            {
                if(con.State ==ConnectionState.Open)//checking wheather the connection is open or not if open then close connection
                con.Close();
            }
            return true;
        }
        public Employee SearchEmplyeeByID(int empId)
        {
            Employee emp = null;
            try
            {
                con.Open();
                SqlParameter p1;
                p1 = new SqlParameter("@eid",empId);
                
                cmd = new SqlCommand();
                cmd.CommandText = "select * from CGEMPLOYEE where EmpId = @empid";
                cmd.CommandType = CommandType.Text;
                cmd.Connection = con;
                //adding params to command
                cmd.Parameters.Add(p1);

                //executing command
                sdr = cmd.ExecuteReader();
                sdr.Read();
                if(sdr.HasRows)
                {
                    emp = new Employee();
                    //binding object with data reader
                    emp.EmpId = Int32.Parse(sdr[0].ToString());
                    emp.EmpName = sdr[1].ToString();
                    emp.Phone = sdr[2].ToString();
                    emp.Addr = sdr[3].ToString();

                }
                
                else
                {
                    flag = false;
                }
            }
            catch (SqlException e)
            {
                throw e;
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                if (con.State == ConnectionState.Open)//checking wheather the connection is open or not if open then close connection
                    con.Close();
            }
            return emp;
        }
        public List<Employee> SearchEmplyeeByName(string empName)
        {
            return new Employee();
        }
        #endregion
    }
}
