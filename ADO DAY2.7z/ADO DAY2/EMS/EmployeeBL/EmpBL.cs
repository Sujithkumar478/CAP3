﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using EmployeeDAL;
using EmployeeEntity;
using EmployeeException;
using System.Threading.Tasks;

namespace EmployeeBL
{
    public class EmpBL
    {
        EmployeeDAO empDAO;
        public EmpBL()
        {
            empDAO = new EmployeeDAO();
        }

        public bool AddEmployee(Employee e1)
        {
            return empDAO.AddEmployee(e1);
        }
        public Employee SearchEmployeeByID(Employee emp1)
        {

        }
    }
        
}
