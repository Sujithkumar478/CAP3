﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace CONARCHDEMO
{
    public partial class Form1 : Form
    {
        SqlConnection con;//for connection with sql
        SqlCommand cmd;//for command
        SqlDataReader sdr;//for data reader//sdr reads 1 row at a time
        public Form1()
        {
            InitializeComponent();
            con = new SqlConnection();
            con.ConnectionString = @"server=.\sqlexpress;Integrated Security = SSPI;Database=EMPLOYEE";//. identifies the server ,integrated security sspi works with before 2000 versions and modern version ,database name
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            con.Open();//OPENING CONNECTION FOR CONNECTED ARCH
            //command method(method 1)
            cmd = new SqlCommand();
            cmd.CommandText = "Select * from PARENT_TBL";
            cmd.CommandType = CommandType.Text;
            cmd.Connection = con;
            
            //(or) command method(method 2)
            cmd = new SqlCommand("Select * from PARENT_TBL", con);
            sdr=cmd.ExecuteReader();
            //Creating a logical table
            DataTable dt = new DataTable();
            dt.Load(sdr);//loading data into table dt
            con.Close();//closing the connection
            //Binding data to grid
            dataGridView1.DataSource = dt;//the table content is displayed in grid
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
