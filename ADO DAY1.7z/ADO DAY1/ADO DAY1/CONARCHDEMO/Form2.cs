﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace CONARCHDEMO
{
    public partial class Form2 : Form
    {
        SqlConnection con;
        SqlCommand cmd;
        SqlDataReader sdr;
        public Form2()
        {
            InitializeComponent();
            con = new SqlConnection();
            con.ConnectionString = @"server=.\sqlexpress;Integrated security = SSPI;DATABASE = EMPLOYEE";
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            con.Open();//OPENING CONNECTION FOR CONNECTED ARCH
            //command method(method 1)
            cmd = new SqlCommand();
            cmd.CommandText = "Select * from CGEMPLOYEE";
            cmd.CommandType = CommandType.Text;
            cmd.Connection = con;

            //(or) command method(method 2)
            cmd = new SqlCommand("Select * from CGEMPLOYEE", con);
            sdr = cmd.ExecuteReader();
            //sdr.Read();
            //if(sdr.HasRows)
            //{
            //    textBox1.Text = sdr[0].ToString();
            //}
            //else
            //{
            //    MessageBox.Show("No record found");
            //}
            //sdr.GetOrdinal("EMPNAME");
            //Creating a logical table
            DataTable dt = new DataTable();
            dt.Load(sdr);//loading data into table dt
            con.Close();//closing the connection
            dataGridView1.DataSource = dt;
            ////binding data to text boxes
            //textBox1.DataBindings.Add("text", dt, "EMPID");
            //textBox2.DataBindings.Add("text", dt, "EMPNAME");
            //textBox3.DataBindings.Add("text", dt, "PHONE");
            //textBox4.DataBindings.Add("text", dt, "ADDR");
            con.Open();
            SqlCommand cmd1 = new SqlCommand();
            cmd1.CommandText = "select count (*) from CGEMPLOYEE ";
            cmd1.CommandType = CommandType.Text;
            cmd1.Connection = con;
            int x =(int)cmd1.ExecuteScalar();
            con.Close();
            MessageBox.Show("Total number of employees"+x);
        }
        private void btnAdd_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlParameter p1, p2, p3, p4;
            p1 = new SqlParameter("@EID", textBox1.Text);
            p2 = new SqlParameter("@ENAME", textBox2.Text);
            p3 = new SqlParameter("@PHONENO", textBox3.Text);
            p4 = new SqlParameter("@ADDRESS", textBox4.Text);
            cmd = new SqlCommand();
            cmd.CommandText = "Insert into CGEMPLOYEE values(@EID,@ENAME,@PHONENO,@ADDRESS)";
          
            //cmd.CommandText = "Insert into CGEMPLOYEE values('" + textBox1.Text + "','" + textBox2.Text + "','" + textBox3.Text + "','" + textBox4.Text + "')";
            cmd.CommandType = CommandType.Text;
            cmd.Connection = con;
            //adding parameters to command
            cmd.Parameters.Add(p1);
            cmd.Parameters.Add(p2);
            cmd.Parameters.Add(p3);
            cmd.Parameters.Add(p4);
            //executing command
            int resCnt =cmd.ExecuteNonQuery();
            MessageBox.Show(resCnt.ToString()+"Record Inserted");
            
                                    

        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlParameter p1, p2;// p3, p4;
            p1 = new SqlParameter("@EID", textBox1.Text);
            p2 = new SqlParameter("@ENAME", textBox2.Text);
            //p3 = new SqlParameter("@PHONENO", textBox3.Text);
            //p4 = new SqlParameter("@ADDRESS", textBox4.Text);

            cmd = new SqlCommand();
            cmd.CommandText = "update CGEMPLOYEE set EMPNAME= @ENAME WHERE EMPID=@EID";

            //cmd.CommandText = "Insert into CGEMPLOYEE values('" + textBox1.Text + "','" + textBox2.Text + "','" + textBox3.Text + "','" + textBox4.Text + "')";
            cmd.CommandType = CommandType.Text;
            cmd.Connection = con;
            ////adding parameters to command
            cmd.Parameters.Add(p1);
            cmd.Parameters.Add(p2);
            //cmd.Parameters.Add(p3);
            //cmd.Parameters.Add(p4);

            //executing command
            int resCnt1 = cmd.ExecuteNonQuery();
            MessageBox.Show(resCnt1.ToString() + "Record IS UPDATED");

        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlParameter p1, p2, p3, p4;
            p1 = new SqlParameter("@EID", textBox1.Text);
            p2 = new SqlParameter("@ENAME", textBox2.Text);
            p3 = new SqlParameter("@PHONENO", textBox3.Text);
            p4 = new SqlParameter("@ADDRESS", textBox4.Text);

            cmd = new SqlCommand();
            cmd.CommandText = "DELETE FROM CGEMPLOYEE WHERE EMPID=@EID";

            //cmd.CommandText = "Insert into CGEMPLOYEE values('" + textBox1.Text + "','" + textBox2.Text + "','" + textBox3.Text + "','" + textBox4.Text + "')";
            cmd.CommandType = CommandType.Text;
            cmd.Connection = con;
            ////adding parameters to command
            cmd.Parameters.Add(p1);
            cmd.Parameters.Add(p2);
            cmd.Parameters.Add(p3);
            cmd.Parameters.Add(p4);

            //executing command
            int resCnt1 = cmd.ExecuteNonQuery();
            MessageBox.Show(resCnt1.ToString() + "Record IS DELETED");
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            con.Open();//OPENING CONNECTION FOR CONNECTED ARCH
            //command method(method 1)
            cmd = new SqlCommand();
            SqlParameter p1;
            p1 = new SqlParameter("@EID", textBox1.Text);
            
            cmd.CommandText = "Select * from CGEMPLOYEE WHERE EMPID=@EID";
            cmd.CommandType = CommandType.Text;
            cmd.Connection = con;
            cmd.Parameters.Add(p1);
            
            
            sdr = cmd.ExecuteReader();
            
            ////Creating a logical table
            DataTable dt = new DataTable();
            dt.Load(sdr);//loading data into table dt
            con.Close();//closing the connection
            dataGridView1.DataSource = dt;

            textBox1.DataBindings.Add("text", dt, "EMPID");
            textBox2.DataBindings.Add("text", dt, "EMPNAME");
            textBox3.DataBindings.Add("text", dt, "PHONE");
            textBox4.DataBindings.Add("text", dt, "ADDR");
        }



        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            
        }
    }
}
